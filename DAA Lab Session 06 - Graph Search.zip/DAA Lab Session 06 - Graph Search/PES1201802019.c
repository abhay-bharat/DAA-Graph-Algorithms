#include "graphSearch.h"


static bool dfs(int s_v,int s_p, int n, int* flag, int* visited, const int graph[][n])
{
  visited[s_v] = 1;
  for(int j = 0;j<n;++j)
  {
    if(graph[s_v][j] == 1 && visited[j] != 0 && j != s_v && j!=s_p)
    {
      *flag = 0;
    }
    else if(graph[s_v][j] == 1 && visited[j] == 0)
    {
      dfs(j,s_v, n,flag,visited, graph);
    }
  }
  return *flag;
}

bool isTree(int n, const int graph[][n])
{
  int start_node;
  start_node = 0;
  int a = 1;
  int* flag = &a; //To indicate that it is a tree
  int* visited = (int*)calloc(n,sizeof(int));
  return dfs(start_node,-1, n,flag,visited,graph);
}

static int pepe_dfs(int s_v,int n,int* visit,int* count,const int graph[][n])
{
	visit[s_v] = 1;
	for(int i =0;i<n;++i)
	{
		if(graph[s_v][i] == 1 && visit[i] == 0)
		{
			*count += 1;
			pepe_dfs(i,n,visit,count,graph);
		}
	}
	return *count;
}

Result pepesAnswers(int n, const int safeSeq[][n])
{
  Result *ans = (Result*)malloc(sizeof(Result));
  int* visit = (int*)calloc(n, sizeof(int));
  int comp_count = 0;
  int a = 0;
  int* count = &a;
  int max = 0;
  int val;
  	for(int j = 0;j<n;++j)
  	{
  		if(visit[j] == 0)
  		{
  			*count = 1;
  			comp_count++;
  			val = pepe_dfs(j,n,visit,count,safeSeq);
  			if(val > max)
  				max = val;
  		}
  	}
  	
  	ans->numDeliveryFrogs = comp_count;
  	ans->maxHouses = max;
  	free(visit);
  return *ans;
}

static int pepe_dfs_2(int s_v, int n, int k,int* visit,int* count,const int graph[][n])
{
	visit[s_v] = 1;
	for(int i =0;i<n;++i)
	{
		if(graph[s_v][i] == 1 && visit[i] == 0 && abs(s_v - i) <= k)
		{
			*count += 1;
			pepe_dfs(i,n,visit,count,graph);
		}
	}
	return *count;
}
Result pepesAnswersWithK(int n, const int safeSeq[][n], int k)
{
  Result *ans = (Result*)malloc(sizeof(Result));
  int* visit = (int*)calloc(n, sizeof(int));
  int comp_count = 0;
  int a = 0;
  int* count = &a;
  int max = 0;
  int val;
  	for(int j = 0;j<n;++j)
  	{
  		if(visit[j] == 0)
  		{
  			*count = 1;
  			comp_count++;
  			val = pepe_dfs_2(j,n,k,visit,count,safeSeq);
  			if(val > max)
  				max = val;
  		}
  	}
  	
  	ans->numDeliveryFrogs = comp_count;
  	ans->maxHouses = max;
  	free(visit);
  return *ans;
}
